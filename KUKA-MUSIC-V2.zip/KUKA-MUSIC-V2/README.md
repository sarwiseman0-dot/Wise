# KUKA MUSIC v2

Interface musicale responsive : accueil, recherche locale, bibliothèque, favoris, import de fichiers audio, lecteur (lecture/pause, précédent/suivant, progression, volume) et configuration PWA.

## Publication GitHub Pages
Téléversez le contenu de ce dossier à la racine du dépôt KUKA-MUSIC : `index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`. Dans Settings > Pages, choisissez Deploy from a branch, la branche par défaut réelle du dépôt (ex. `main` ou `principal`) et `/(root)`. Ouvrez ensuite l'adresse fournie par GitHub Pages, qui doit pointer vers le dépôt KUKA-MUSIC.

## Limites
Cette version lit uniquement les fichiers audio que l'utilisateur sélectionne sur son appareil. Les fichiers ne sont pas hébergés, partagés ou synchronisés. Aucun catalogue de streaming, compte utilisateur ou serveur n'est inclus. Pour diffuser un catalogue, il faudra obtenir les licences musicales et créer un backend. Sur Android, le site peut être ajouté à l'écran d'accueil comme PWA selon le navigateur; ce n'est pas encore un APK natif.
